

  requirejs.config({
    'paths': {
      	'jquery' 				: '/etc/designs/aem-example/clientlibs/js/libs/jquery.min',
		'runFirstOnce' 			: '/etc/designs/aem-example/clientlibs/js/libs/runFirstOnce',
		'videojs' 				: '/etc/designs/aem-example/clientlibs/js/libs/video',
        'video-overlay' 		: '/etc/designs/aem-example/clientlibs/js/libs/video-overlay',
		'videojs-youtube' 		: '/etc/designs/aem-example/clientlibs/js/libs/video-youtube'

    },

    waitSeconds: 30,
    shim: {
        	'pagination': {
			deps: ['jquery']
            },
            'jquery.socialfeed': {
                deps: ['doT']
            },
            'doT': {
                deps: ['codebird','moment']
            },
            'once': {
                deps: ['jquery']
            },
            'runFirstOnce': {
                deps: ['jquery']
            },
            'waypoints': {
                deps: ['jquery']
            },
            'owlcarousel': {
                deps: ['jquery']
            },
            'scrollToFixed': {
                deps: ['jquery']
            },
            'handlebars': {
                exports: 'Handlebars'
            },
            'slick': {
                deps: ['jquery']
            },
            'fastclick': {
                deps: ['jquery']
            },
            'videojs-youtube': {
                deps: ['videojs']
            },
            'ddslick': {
                deps: ['jquery']
            },
            'video-overlay': {
                deps: ['videojs', 'videojs-youtube']
            },
            'bootstrapValidator': {
                deps: ['jquery']
            },
            'accordion': {
                deps: ['jquery']
            },
            'jquery-ui': {
                deps: ['jquery']
            },
            'search': {
                deps: ['jquery', 'once']
            },
            'noe': {
                deps : ['jquery', 'runFirstOnce']
            },
            'socialShare': {
                deps: ['jquery']
            },
        	'lazyload': {
                deps: ['jquery']
            },
            'jquery.scrollTo': {
                deps: ['jquery']
            },
            'dealer-locator': {
                deps: ['jquery','jquery.scrollTo']
            },
           	'youtubeInit': {
           		deps : ['jquery', 'videojs', 'videojs-youtube']
            },
            'countDownTimer' : {
              deps : ['jquery']
            },
			'actual' : {
              deps : ['jquery']
            },
			'videoPlayer' : {
              deps : ['jquery']
            },
        	'dish' : {
              deps : ['jquery']
            },
			'youkuPlayer' : {
              deps : ['jquery']
            }
        }
  });

var config = window.config || {};

// Globally initiated libraries should be included here.
// Please document it properly.
// require('videojs', [videojs], function(videojs){
//   if (!window.videojs) {
//     window.videojs = videojs;
//   }
// })
// responsive-image is used to replace images with the proper rendition
// for the current screen size.
require(['videojs'], function(videojs ) {
	window.videojs = videojs;
});

require(['videojs-youtube']);

