define("hotspot", ["jquery", "video-overlay", "runFirstOnce"], function(b, a) {
    return {
        init: function(c, e) {
            var d = this,
                f = e.imageConfigFlag,
                g = e.imgSrc;
            b(".hotspot-items button").hide();
            b(c).runFirstOnce("hotspot", function() {
                d.options = e || {};
                d.options.element = this;
                d.hotspots(f, g)
            });
            if (this.isTouchDevice()) {
                b("body").addClass("touch")
            }
        },
        hotspots: function(d, l) {
            var n = this,
                m = b(this.options.element),
                i = 0,
                e = 0,
                h = 0,
                g, f, k;
            n.hotspot(m, d);
            var c = b(".hotspot-items", m),
                j = b(".hotspot-point", c);
            j.each(function(o, p) {
                b(this).on("click", function(q) {
                    if (b(c).children(".buttonFocus").length > 0) {
                        if (b(this).hasClass("buttonFocus")) {
                            b(j).removeClass("buttonFocus")
                        } else {
                            b(j).removeClass("buttonFocus");
                            b(this).toggleClass("buttonFocus");
                            n.scrollDown(b(this))
                        }
                    } else {
                        b(this).toggleClass("buttonFocus");
                        n.scrollDown(b(this))
                    }
                })
            });
            b(document).on("click", function(o) {
                if (!b(o.target).hasClass("hotspot-point")) {
                    b(".hotspot-point").removeClass("buttonFocus")
                }
            });
            b(window).on("resize load", function() {
                if (d.length > 0) {
                    b.each(d, function(o, p) {
                        if (o == 0) {
                            i = p.devicewidth;
                            f = l + ".transform/Rend_" + p.imagewidth + "X" + p.imageheight + "/image.jpg"
                        }
                        if (o == 1) {
                            e = p.devicewidth;
                            k = l + ".transform/Rend_" + p.imagewidth + "X" + p.imageheight + "/image.jpg"
                        }
                    });
                    if (e > i) {
                        h = e
                    } else {
                        h = i
                    }
                    if (b(window).width() <= h) {
                        g = f
                    } else {
                        g = k
                    }
                    b(".hotspot-img").attr("src", g)
                }
                n.hotspot(m, d)
            })
        },
        hotspot: function(d, e) {
            var c = this;
            if (e.length === 0) {
                c.positionCords(d, e)
            } else {
                b(".org-img").load(function() {
                    c.positionCords(d, e)
                })
            }
        },
        positionCords: function(c, d) {
            b(".hotspot-items button").show();
            b(".hotspot-point", c).blur().each(function() {
                var l = b(this),
                    h = b(".org-img", c),
                    j = b(".main-img"),
                    i = "naturalHeight",
                    g = "naturalWidth",
                    k = l.data(),
                    e = {};
                if (d.length === 0) {
                    e = {
                        top: (parseFloat(k.posTop) / h[0][i]) * 100 + "%",
                        left: (parseFloat(k.posLeft) / h[0][g]) * 100 + "%"
                    }
                } else {
                    e = {
                        top: (parseFloat(k.posTop) / j[0][i]) * 100 + "%",
                        left: (parseFloat(k.posLeft) / j[0][g]) * 100 + "%"
                    }
                }
                var f = {
                    top: h.height() * (parseFloat(e.top) / 100) + "px",
                    left: h.width() * (parseFloat(e.left) / 100) + "px"
                };
                l.css(f)
            })
        },
        scrollDown: function(c) {
            b("html,body").animate({
                scrollTop: c.offset().top - 200
            }, 400)
        },
        isTouchDevice: function() {
            return true == ("ontouchstart" in window || window.DocumentTouch && document instanceof DocumentTouch)
        }
    }
});