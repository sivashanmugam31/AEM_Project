  requirejs.config({
    'paths': {
      // injector
        
    }
  });
